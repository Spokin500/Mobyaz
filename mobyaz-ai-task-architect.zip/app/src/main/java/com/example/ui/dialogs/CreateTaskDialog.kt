package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.TaskPriority
import com.example.data.model.TeamMember
import com.example.ui.components.PriorityBadge
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate600
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900

@Composable
fun CreateTaskDialog(
    teamMembers: List<TeamMember>,
    currentMember: TeamMember,
    onDismiss: () -> Unit,
    onConfirm: (
        title: String,
        description: String,
        priority: TaskPriority,
        assignee: TeamMember,
        tags: String,
        dueDate: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf(TaskPriority.MEDIUM) }
    var selectedAssignee by remember { mutableStateOf(currentMember) }
    var tags by remember { mutableStateOf("Sprint 1") }
    var dueDate by remember { mutableStateOf("2026-11-20") }

    var showPriorityDropdown by remember { mutableStateOf(false) }
    var showAssigneeDropdown by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .testTag("create_task_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Slate900)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Yeni Görev Oluştur",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Ekip panosuna gerçek zamanlı senkronize edilecek",
                    fontSize = 11.sp,
                    color = Slate400
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Title
                Text("Görev Başlığı *", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Slate400)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text("Örn: API Entegrasyon Testleri", color = Slate600, fontSize = 13.sp) },
                    modifier = Modifier.fillMaxWidth().testTag("new_task_title_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Slate800,
                        unfocusedContainerColor = Slate800,
                        focusedBorderColor = IndigoPrimary,
                        unfocusedBorderColor = Slate700,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Description
                Text("Detaylı Açıklama", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Slate400)
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    placeholder = { Text("Kabul kriterleri, teknik notlar…", color = Slate600, fontSize = 13.sp) },
                    modifier = Modifier.fillMaxWidth().testTag("new_task_desc_input"),
                    minLines = 3,
                    maxLines = 4,
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Slate800,
                        unfocusedContainerColor = Slate800,
                        focusedBorderColor = IndigoPrimary,
                        unfocusedBorderColor = Slate700,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Priority & Assignee Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Priority Selector
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Öncelik", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Slate400)
                        Spacer(modifier = Modifier.height(4.dp))
                        Box {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Slate800)
                                    .clickable { showPriorityDropdown = true }
                                    .padding(horizontal = 12.dp, vertical = 12.dp)
                            ) {
                                PriorityBadge(priority = priority)
                            }

                            DropdownMenu(
                                expanded = showPriorityDropdown,
                                onDismissRequest = { showPriorityDropdown = false },
                                modifier = Modifier.background(Slate800)
                            ) {
                                TaskPriority.values().forEach { p ->
                                    DropdownMenuItem(
                                        text = { PriorityBadge(priority = p) },
                                        onClick = {
                                            priority = p
                                            showPriorityDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Assignee Selector
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Atanan Üye", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Slate400)
                        Spacer(modifier = Modifier.height(4.dp))
                        Box {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Slate800)
                                    .clickable { showAssigneeDropdown = true }
                                    .padding(horizontal = 8.dp, vertical = 10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clip(CircleShape)
                                        .background(Color(selectedAssignee.colorHex)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = selectedAssignee.avatarInitials,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = selectedAssignee.name.split(" ").firstOrNull() ?: selectedAssignee.name,
                                    fontSize = 12.sp,
                                    color = Color.White,
                                    maxLines = 1
                                )
                            }

                            DropdownMenu(
                                expanded = showAssigneeDropdown,
                                onDismissRequest = { showAssigneeDropdown = false },
                                modifier = Modifier.background(Slate800)
                            ) {
                                teamMembers.forEach { m ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(18.dp)
                                                        .clip(CircleShape)
                                                        .background(Color(m.colorHex)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(m.avatarInitials, fontSize = 8.sp, color = Color.White)
                                                }
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(m.name, color = Color.White, fontSize = 12.sp)
                                            }
                                        },
                                        onClick = {
                                            selectedAssignee = m
                                            showAssigneeDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Tags & Due Date Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Etiketler", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Slate400)
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = tags,
                            onValueChange = { tags = it },
                            placeholder = { Text("Sprint 1, UI", color = Slate600, fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Slate800,
                                unfocusedContainerColor = Slate800,
                                focusedBorderColor = IndigoPrimary,
                                unfocusedBorderColor = Slate700,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text("Bitiş Tarihi", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Slate400)
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedTextField(
                            value = dueDate,
                            onValueChange = { dueDate = it },
                            placeholder = { Text("YYYY-MM-DD", color = Slate600, fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Slate800,
                                unfocusedContainerColor = Slate800,
                                focusedBorderColor = IndigoPrimary,
                                unfocusedBorderColor = Slate700,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Slate400)
                    ) {
                        Text("İptal")
                    }

                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                onConfirm(
                                    title.trim(),
                                    description.trim(),
                                    priority,
                                    selectedAssignee,
                                    tags.trim(),
                                    dueDate.trim()
                                )
                            }
                        },
                        enabled = title.isNotBlank(),
                        modifier = Modifier.weight(1f).testTag("save_task_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = IndigoPrimary,
                            disabledContainerColor = Slate800
                        )
                    ) {
                        Text("Kaydet & Senkronla", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
