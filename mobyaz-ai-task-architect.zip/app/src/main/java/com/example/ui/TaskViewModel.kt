package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.ActivityLogItem
import com.example.data.model.SyncState
import com.example.data.model.TaskItem
import com.example.data.model.TaskPriority
import com.example.data.model.TaskStatus
import com.example.data.model.TeamMember
import com.example.data.repository.TaskRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TaskViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getInstance(application)
    private val repository = TaskRepository(database)

    val tasks: StateFlow<List<TaskItem>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val teamMembers: StateFlow<List<TeamMember>> = repository.teamMembers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activityLogs: StateFlow<List<ActivityLogItem>> = repository.activityLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val syncState: StateFlow<SyncState> = repository.syncState
    val currentMember: StateFlow<TeamMember> = repository.currentMember
    val lastSyncTime: StateFlow<Long> = repository.lastSyncTime

    val searchQuery = MutableStateFlow("")
    val selectedFilter = MutableStateFlow("Tümü")
    val selectedTab = MutableStateFlow(0) // 0: Tasks, 1: Board, 2: Team, 3: AI Assistant

    // Filtered tasks combination
    val filteredTasks: StateFlow<List<TaskItem>> = combine(
        tasks,
        searchQuery,
        selectedFilter,
        currentMember
    ) { allTasks, query, filter, member ->
        allTasks.filter { task ->
            val matchesQuery = query.isEmpty() ||
                    task.title.contains(query, ignoreCase = true) ||
                    task.description.contains(query, ignoreCase = true) ||
                    task.tags.contains(query, ignoreCase = true)

            val matchesFilter = when (filter) {
                "Tümü" -> true
                "Bana Atananlar" -> task.assigneeId == member.id
                "Acil" -> task.priority == TaskPriority.URGENT || task.priority == TaskPriority.HIGH
                "Yapılacak" -> task.status == TaskStatus.TODO
                "Sürüyor" -> task.status == TaskStatus.IN_PROGRESS
                "İncelemede" -> task.status == TaskStatus.REVIEW
                "Tamamlandı" -> task.status == TaskStatus.DONE
                else -> true
            }

            matchesQuery && matchesFilter
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectTab(tabIndex: Int) {
        selectedTab.value = tabIndex
    }

    fun setFilter(filter: String) {
        selectedFilter.value = filter
    }

    fun setSearch(query: String) {
        searchQuery.value = query
    }

    fun switchMember(member: TeamMember) {
        repository.switchActiveMember(member)
    }

    fun addNewTask(
        title: String,
        description: String,
        priority: TaskPriority,
        assignee: TeamMember?,
        tags: String,
        dueDate: String
    ) {
        viewModelScope.launch {
            repository.insertTask(
                title = title,
                description = description,
                status = TaskStatus.TODO,
                priority = priority,
                assignee = assignee,
                tags = tags,
                dueDate = dueDate
            )
        }
    }

    fun updateTaskStatus(task: TaskItem, newStatus: TaskStatus) {
        viewModelScope.launch {
            repository.updateTaskStatus(task, newStatus)
        }
    }

    fun deleteTask(task: TaskItem) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    fun triggerSync() {
        repository.triggerManualSync()
    }

    fun simulateIncomingTeamEvent() {
        repository.simulatePeerEvent()
    }

    /**
     * Smart template generator: Quickly generates collaborative subtasks / architecture backlog
     */
    fun generatePresetArchitectureTasks(templateType: String) {
        viewModelScope.launch {
            when (templateType) {
                "Auth" -> {
                    addNewTask(
                        title = "OAuth 2.0 & JWT Entegrasyonu",
                        description = "Kullanıcı oturum güvenliği ve token yenileme mimarisini kur.",
                        priority = TaskPriority.HIGH,
                        assignee = teamMembers.value.getOrNull(2) ?: currentMember.value,
                        tags = "Security, Backend",
                        dueDate = "2026-11-18"
                    )
                }
                "WebSocket" -> {
                    addNewTask(
                        title = "Anlık Mesajlaşma & Presence Protokolü",
                        description = "Ekip üyelerinin online durumunu ve anlık aktivitesini ilet.",
                        priority = TaskPriority.URGENT,
                        assignee = teamMembers.value.getOrNull(0) ?: currentMember.value,
                        tags = "RealTime, Sockets",
                        dueDate = "2026-11-16"
                    )
                }
                "DesignSystem" -> {
                    addNewTask(
                        title = "MobYaz Design System Tokenları",
                        description = "Tipografi, renk paleti ve erişilebilir M3 bileşen kütüphanesini hazırla.",
                        priority = TaskPriority.MEDIUM,
                        assignee = teamMembers.value.getOrNull(3) ?: currentMember.value,
                        tags = "UI/UX, Compose",
                        dueDate = "2026-11-20"
                    )
                }
            }
        }
    }
}
