package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Modern MobYaz Dark Slate & Indigo Palette
val Slate950 = Color(0xFF0A0F1D)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)

// Vibrant Accent Colors
val IndigoPrimary = Color(0xFF6366F1)
val IndigoSecondary = Color(0xFF818CF8)
val CyanAccent = Color(0xFF06B6D4)
val EmeraldSuccess = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val RoseUrgent = Color(0xFFF43F5E)
val PurpleCard = Color(0xFF242247)

// Status Colors
val StatusTodoColor = Color(0xFF64748B)
val StatusInProgressColor = Color(0xFF3B82F6)
val StatusReviewColor = Color(0xFF8B5CF6)
val StatusDoneColor = Color(0xFF10B981)
