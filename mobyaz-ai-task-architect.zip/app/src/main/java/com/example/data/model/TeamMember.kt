package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "team_members")
data class TeamMember(
    @PrimaryKey
    val id: String,
    val name: String,
    val role: String,
    val email: String,
    val avatarInitials: String,
    val colorHex: Long = 0xFF6366F1,
    val isOnline: Boolean = true,
    val assignedTasksCount: Int = 0
)

@Entity(tableName = "activity_logs")
data class ActivityLogItem(
    @PrimaryKey
    val id: String,
    val memberName: String,
    val actionText: String,
    val taskTitle: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class SyncState {
    SYNCED,
    SYNCING,
    OFFLINE
}
