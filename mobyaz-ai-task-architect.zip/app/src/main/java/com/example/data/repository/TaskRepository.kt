package com.example.data.repository

import com.example.data.db.AppDatabase
import com.example.data.model.ActivityLogItem
import com.example.data.model.SyncState
import com.example.data.model.TaskItem
import com.example.data.model.TaskPriority
import com.example.data.model.TaskStatus
import com.example.data.model.TeamMember
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID

class TaskRepository(private val database: AppDatabase) {
    private val taskDao = database.taskDao()
    private val teamMemberDao = database.teamMemberDao()
    private val activityLogDao = database.activityLogDao()
    private val coroutineScope = CoroutineScope(Dispatchers.IO)

    val allTasks: Flow<List<TaskItem>> = taskDao.getAllTasks()
    val teamMembers: Flow<List<TeamMember>> = teamMemberDao.getAllMembers()
    val activityLogs: Flow<List<ActivityLogItem>> = activityLogDao.getRecentActivities()

    private val _syncState = MutableStateFlow(SyncState.SYNCED)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    private val _currentMember = MutableStateFlow(AppDatabase.initialMembers[0])
    val currentMember: StateFlow<TeamMember> = _currentMember.asStateFlow()

    private val _lastSyncTime = MutableStateFlow(System.currentTimeMillis())
    val lastSyncTime: StateFlow<Long> = _lastSyncTime.asStateFlow()

    init {
        // Ensure database is populated if opened first time
        coroutineScope.launch {
            val existingTasks = taskDao.getAllTasks().first()
            if (existingTasks.isEmpty()) {
                teamMemberDao.insertMembers(AppDatabase.initialMembers)
                taskDao.insertTasks(AppDatabase.initialTasks)
                activityLogDao.insertLog(
                    ActivityLogItem(
                        id = "act-welcome",
                        memberName = "MobYaz Sistemi",
                        actionText = "Ekip panosu ve görevler hazırlandı",
                        taskTitle = "Başlangıç Kurulumu"
                    )
                )
            }
        }
    }

    fun switchActiveMember(member: TeamMember) {
        _currentMember.value = member
    }

    suspend fun insertTask(
        title: String,
        description: String,
        status: TaskStatus = TaskStatus.TODO,
        priority: TaskPriority = TaskPriority.MEDIUM,
        assignee: TeamMember? = null,
        tags: String = "Sprint 1",
        dueDate: String = "2026-11-20"
    ) {
        val assigned = assignee ?: _currentMember.value
        val task = TaskItem(
            id = "tsk-${UUID.randomUUID().toString().take(6)}",
            title = title,
            description = description,
            status = status,
            priority = priority,
            assigneeId = assigned.id,
            assigneeName = assigned.name,
            projectName = "MobYaz Team",
            tags = tags,
            dueDate = dueDate,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            isSynced = false
        )
        taskDao.insertTask(task)

        // Log team activity
        activityLogDao.insertLog(
            ActivityLogItem(
                id = UUID.randomUUID().toString(),
                memberName = _currentMember.value.name,
                actionText = "Yeni görev oluşturdu ve atadı: ${assigned.name}",
                taskTitle = title
            )
        )

        triggerSyncPulse()
    }

    suspend fun updateTaskStatus(task: TaskItem, newStatus: TaskStatus) {
        if (task.status == newStatus) return
        taskDao.updateStatus(task.id, newStatus, System.currentTimeMillis())

        activityLogDao.insertLog(
            ActivityLogItem(
                id = UUID.randomUUID().toString(),
                memberName = _currentMember.value.name,
                actionText = "Görev durumunu '${newStatus.titleTr}' yaptı",
                taskTitle = task.title
            )
        )

        triggerSyncPulse()
    }

    suspend fun updateTask(task: TaskItem) {
        taskDao.updateTask(task.copy(updatedAt = System.currentTimeMillis(), isSynced = false))
        activityLogDao.insertLog(
            ActivityLogItem(
                id = UUID.randomUUID().toString(),
                memberName = _currentMember.value.name,
                actionText = "Görevi güncelledi",
                taskTitle = task.title
            )
        )
        triggerSyncPulse()
    }

    suspend fun deleteTask(task: TaskItem) {
        taskDao.deleteTask(task)
        activityLogDao.insertLog(
            ActivityLogItem(
                id = UUID.randomUUID().toString(),
                memberName = _currentMember.value.name,
                actionText = "Görevi sildi",
                taskTitle = task.title
            )
        )
        triggerSyncPulse()
    }

    fun triggerManualSync() {
        triggerSyncPulse()
    }

    private fun triggerSyncPulse() {
        coroutineScope.launch {
            _syncState.value = SyncState.SYNCING
            delay(900) // Simulating network round-trip & WebSocket ack
            _syncState.value = SyncState.SYNCED
            _lastSyncTime.value = System.currentTimeMillis()
        }
    }

    /**
     * Simulates live peer activity incoming in real-time from other team members.
     * Demonstrates collaborative multiplayer sync.
     */
    fun simulatePeerEvent() {
        coroutineScope.launch {
            val members = AppDatabase.initialMembers.filter { it.id != _currentMember.value.id }
            val randomMember = members.random()
            val tasks = taskDao.getAllTasks().first()
            if (tasks.isNotEmpty()) {
                val targetTask = tasks.random()
                val nextStatus = when (targetTask.status) {
                    TaskStatus.TODO -> TaskStatus.IN_PROGRESS
                    TaskStatus.IN_PROGRESS -> TaskStatus.REVIEW
                    TaskStatus.REVIEW -> TaskStatus.DONE
                    TaskStatus.DONE -> TaskStatus.IN_PROGRESS
                }

                _syncState.value = SyncState.SYNCING
                delay(600)
                taskDao.updateStatus(targetTask.id, nextStatus, System.currentTimeMillis())
                activityLogDao.insertLog(
                    ActivityLogItem(
                        id = UUID.randomUUID().toString(),
                        memberName = randomMember.name,
                        actionText = "Uzaktan senkronize etti: '${nextStatus.titleTr}'",
                        taskTitle = targetTask.title
                    )
                )
                _syncState.value = SyncState.SYNCED
                _lastSyncTime.value = System.currentTimeMillis()
            }
        }
    }
}
