package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.ActivityLogItem
import com.example.data.model.TaskItem
import com.example.data.model.TaskPriority
import com.example.data.model.TaskStatus
import com.example.data.model.TeamMember
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [TaskItem::class, TeamMember::class, ActivityLogItem::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun teamMemberDao(): TeamMemberDao
    abstract fun activityLogDao(): ActivityLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mobyaz_tasks.db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Populate default starter data
                            CoroutineScope(Dispatchers.IO).launch {
                                val database = getInstance(context)
                                database.teamMemberDao().insertMembers(initialMembers)
                                database.taskDao().insertTasks(initialTasks)
                                database.activityLogDao().insertLog(
                                    ActivityLogItem(
                                        id = "act-init-1",
                                        memberName = "Ahmet Yılmaz",
                                        actionText = "MobYaz Projesini başlattı",
                                        taskTitle = "Genel Kurulum",
                                        timestamp = System.currentTimeMillis() - 3600000
                                    )
                                )
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        val initialMembers = listOf(
            TeamMember(
                id = "usr-1",
                name = "Ahmet Yılmaz",
                role = "Lead Architect",
                email = "ahmet@mobyaz.dev",
                avatarInitials = "AY",
                colorHex = 0xFF6366F1,
                isOnline = true,
                assignedTasksCount = 3
            ),
            TeamMember(
                id = "usr-2",
                name = "Zeynep Kaya",
                role = "Senior Frontend",
                email = "zeynep@mobyaz.dev",
                avatarInitials = "ZK",
                colorHex = 0xFF06B6D4,
                isOnline = true,
                assignedTasksCount = 2
            ),
            TeamMember(
                id = "usr-3",
                name = "Can Demir",
                role = "Backend & Cloud Dev",
                email = "can@mobyaz.dev",
                avatarInitials = "CD",
                colorHex = 0xFF10B981,
                isOnline = false,
                assignedTasksCount = 1
            ),
            TeamMember(
                id = "usr-4",
                name = "Selin Arslan",
                role = "UI/UX Designer",
                email = "selin@mobyaz.dev",
                avatarInitials = "SA",
                colorHex = 0xFFF59E0B,
                isOnline = true,
                assignedTasksCount = 2
            )
        )

        val initialTasks = listOf(
            TaskItem(
                id = "tsk-101",
                title = "Gerçek Zamanlı WebSocket Senkron Motoru",
                description = "Ekip üyeleri arasında anlık durum güncellemelerini dağıtan çift yönlü senkronizasyon protokolünü tamamla.",
                status = TaskStatus.IN_PROGRESS,
                priority = TaskPriority.URGENT,
                assigneeId = "usr-1",
                assigneeName = "Ahmet Yılmaz",
                projectName = "MobYaz Sync",
                tags = "Sprint 1, Backend, Sync",
                dueDate = "2026-11-12",
                createdAt = System.currentTimeMillis() - 86400000 * 2,
                updatedAt = System.currentTimeMillis() - 3600000 * 2,
                isSynced = true
            ),
            TaskItem(
                id = "tsk-102",
                title = "Kanban Pano Sürükle-Bırak Etkileşimi",
                description = "Pano görünümünde sütunlar arası görev taşıma ve anlık durum geçiş animasyonlarını tasarla.",
                status = TaskStatus.TODO,
                priority = TaskPriority.HIGH,
                assigneeId = "usr-2",
                assigneeName = "Zeynep Kaya",
                projectName = "MobYaz UI",
                tags = "Sprint 1, Compose, UI",
                dueDate = "2026-11-14",
                createdAt = System.currentTimeMillis() - 86400000,
                updatedAt = System.currentTimeMillis() - 86400000,
                isSynced = true
            ),
            TaskItem(
                id = "tsk-103",
                title = "Ekip İşbirliği ve Aktivite Akışı",
                description = "Kim hangi görevi güncelledi, tamamladı veya atandı bilgisini canlı akışta göster.",
                status = TaskStatus.REVIEW,
                priority = TaskPriority.MEDIUM,
                assigneeId = "usr-4",
                assigneeName = "Selin Arslan",
                projectName = "MobYaz Team",
                tags = "Design, UX, Team",
                dueDate = "2026-11-13",
                createdAt = System.currentTimeMillis() - 86400000 * 3,
                updatedAt = System.currentTimeMillis() - 3600000 * 5,
                isSynced = true
            ),
            TaskItem(
                id = "tsk-104",
                title = "Çevrimdışı Veritabanı ve Çakışma Yönetimi",
                description = "Ağ bağlantısı koptuğunda yerel Room kuyruğunda değişiklikleri sakla ve bağlanınca otomatik senkronize et.",
                status = TaskStatus.DONE,
                priority = TaskPriority.HIGH,
                assigneeId = "usr-3",
                assigneeName = "Can Demir",
                projectName = "MobYaz Core",
                tags = "Room, Offline, Core",
                dueDate = "2026-11-10",
                createdAt = System.currentTimeMillis() - 86400000 * 4,
                updatedAt = System.currentTimeMillis() - 3600000 * 12,
                isSynced = true
            )
        )
    }
}
