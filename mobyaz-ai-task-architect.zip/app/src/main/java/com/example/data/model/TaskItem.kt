package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TaskStatus(val titleTr: String) {
    TODO("Yapılacak"),
    IN_PROGRESS("Sürüyor"),
    REVIEW("İncelemede"),
    DONE("Tamamlandı")
}

enum class TaskPriority(val titleTr: String) {
    LOW("Düşük"),
    MEDIUM("Orta"),
    HIGH("Yüksek"),
    URGENT("Acil")
}

@Entity(tableName = "tasks")
data class TaskItem(
    @PrimaryKey
    val id: String,
    val title: String,
    val description: String,
    val status: TaskStatus = TaskStatus.TODO,
    val priority: TaskPriority = TaskPriority.MEDIUM,
    val assigneeId: String = "",
    val assigneeName: String = "",
    val projectName: String = "MobYaz Core",
    val tags: String = "Sprint 1", // Comma-separated tags
    val dueDate: String = "2026-11-15",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isSynced: Boolean = true
)
