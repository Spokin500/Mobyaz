package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Group
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.ui.TaskViewModel
import com.example.ui.components.SyncHeader
import com.example.ui.dialogs.CreateTaskDialog
import com.example.ui.screens.KanbanBoardScreen
import com.example.ui.screens.MobYazAiScreen
import com.example.ui.screens.TaskListScreen
import com.example.ui.screens.TeamCollaborationScreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.IndigoPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.Slate400
import com.example.ui.theme.Slate800
import com.example.ui.theme.Slate900
import com.example.ui.theme.Slate950

class MainActivity : ComponentActivity() {
    private val viewModel: TaskViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MobYazApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MobYazApp(viewModel: TaskViewModel) {
    val tasks by viewModel.filteredTasks.collectAsState()
    val allTasks by viewModel.tasks.collectAsState()
    val teamMembers by viewModel.teamMembers.collectAsState()
    val activityLogs by viewModel.activityLogs.collectAsState()
    val syncState by viewModel.syncState.collectAsState()
    val currentMember by viewModel.currentMember.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()

    var showCreateDialog by remember { mutableStateOf(false) }

    // Handle back button: if not on Home tab (0), return to Home tab
    if (selectedTab != 0) {
        BackHandler {
            viewModel.selectTab(0)
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950),
        topBar = {
            Column(modifier = Modifier.statusBarsPadding()) {
                SyncHeader(
                    syncState = syncState,
                    currentMember = currentMember,
                    teamMembers = teamMembers,
                    onTriggerSync = { viewModel.triggerSync() },
                    onSwitchMember = { member -> viewModel.switchMember(member) }
                )
            }
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding(),
                containerColor = Slate900,
                contentColor = Color.White
            ) {
                val navItems = listOf(
                    Triple(0, "Görevler", Icons.Default.Checklist),
                    Triple(1, "Pano", Icons.Default.Dashboard),
                    Triple(2, "Ekip", Icons.Default.Group),
                    Triple(3, "MobYaz AI", Icons.Default.AutoAwesome)
                )

                navItems.forEach { (index, title, icon) ->
                    val isSelected = selectedTab == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.selectTab(index) },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = title,
                                tint = if (isSelected) CyanAccent else Slate400
                            )
                        },
                        label = {
                            Text(
                                text = title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else Slate400
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyanAccent,
                            selectedTextColor = Color.White,
                            indicatorColor = Slate800,
                            unselectedIconColor = Slate400,
                            unselectedTextColor = Slate400
                        ),
                        modifier = Modifier.testTag("nav_tab_$index")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "screen_transition"
            ) { targetScreen ->
                when (targetScreen) {
                    0 -> TaskListScreen(
                        tasks = tasks,
                        allTasks = allTasks,
                        searchQuery = searchQuery,
                        selectedFilter = selectedFilter,
                        onSearchChange = { viewModel.setSearch(it) },
                        onFilterChange = { viewModel.setFilter(it) },
                        onStatusChange = { task, newStatus -> viewModel.updateTaskStatus(task, newStatus) },
                        onDeleteTask = { task -> viewModel.deleteTask(task) },
                        onAddNewTask = { showCreateDialog = true }
                    )
                    1 -> KanbanBoardScreen(
                        tasks = allTasks,
                        onStatusChange = { task, newStatus -> viewModel.updateTaskStatus(task, newStatus) },
                        onAddNewTask = { showCreateDialog = true }
                    )
                    2 -> TeamCollaborationScreen(
                        currentMember = currentMember,
                        teamMembers = teamMembers,
                        activityLogs = activityLogs,
                        tasks = allTasks,
                        onSwitchMember = { member -> viewModel.switchMember(member) },
                        onSimulatePeerActivity = { viewModel.simulateIncomingTeamEvent() },
                        onTriggerSync = { viewModel.triggerSync() }
                    )
                    3 -> MobYazAiScreen(
                        currentMember = currentMember,
                        onGenerateArchitectureTask = { type -> viewModel.generatePresetArchitectureTasks(type) },
                        onCustomTaskGenerated = { title, desc, priority, tags ->
                            viewModel.addNewTask(
                                title = title,
                                description = desc,
                                priority = priority,
                                assignee = currentMember,
                                tags = tags,
                                dueDate = "2026-11-20"
                            )
                        }
                    )
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateTaskDialog(
            teamMembers = teamMembers,
            currentMember = currentMember,
            onDismiss = { showCreateDialog = false },
            onConfirm = { title, description, priority, assignee, tags, dueDate ->
                viewModel.addNewTask(
                    title = title,
                    description = description,
                    priority = priority,
                    assignee = assignee,
                    tags = tags,
                    dueDate = dueDate
                )
                showCreateDialog = false
            }
        )
    }
}
